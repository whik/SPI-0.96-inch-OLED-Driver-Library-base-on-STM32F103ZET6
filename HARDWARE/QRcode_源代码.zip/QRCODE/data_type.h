#ifndef __DATA_TYPE_H__
#define __DATA_TYPE_H__

typedef unsigned char   		bool;      /* 8-bit*/

#ifndef NULL
	#define NULL 0
#endif

#ifndef TRUE
	#define TRUE 1
#endif

#ifndef FALSE
	#define FALSE 0
#endif

#endif
